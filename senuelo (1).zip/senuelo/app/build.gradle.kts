plugins {
    id("com.android.application")
}

android {
    namespace = "com.senuelo.zona"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.senuelo.zona"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

package com.senuelo.zona;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("Desliza el panel de control, pulsa el lápiz de editar y arrastra el botón \"Zona WiFi\" a tus accesos.");
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(48, 48, 48, 48);
        tv.setTextSize(18);
        setContentView(tv);
    }
}

package com.senuelo.zona;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class SenueloTileService extends TileService {

    private static final String PREFS = "senuelo";
    private static final String KEY_ON = "on";

    @Override
    public void onStartListening() {
        super.onStartListening();
        refrescar();
    }

    @Override
    public void onClick() {
        super.onClick();
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        boolean nuevo = !sp.getBoolean(KEY_ON, false);
        sp.edit().putBoolean(KEY_ON, nuevo).apply();
        refrescar();
    }

    private void refrescar() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean on = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ON, false);
        tile.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (Build.VERSION.SDK_INT >= 29) {
            tile.setSubtitle(on ? "Activada" : "Desactivada");
        }
        tile.updateTile();
    }
}
